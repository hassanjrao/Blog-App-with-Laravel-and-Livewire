<div class="content content-boxed">
    <div class="row">

        


        
        <div class="col-lg-2">
            <div class="row ">

                <?php $__currentLoopData = $leftBars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ind => $leftBar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="col-lg-12">
                        <a class="block block-rounded block-link-pop overflow-hidden" href="<?php echo e($leftBar->link); ?>">
                            <img class="img-fluid" src="<?php echo e(asset('storage/left-bars/' . $leftBar->image)); ?>"
                                alt="">
                            <div class="block-content">

                                <p class="fs-sm text-primary">
                                    <?php echo e($leftBar->description); ?>

                                </p>
                            </div>
                        </a>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
        



        <!-- Story -->
        <div class="col-lg-8">

            <div class="row ">
                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ind => $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="col-lg-6">

                        <a class="block block-rounded block-link-pop overflow-hidden"
                            href="<?php echo e(route('blog.show', [$blog->id, $blog->slug])); ?>">
                            <div class="block-content">
                                <h4 class="mb-1">
                                    <?php echo e($blog->name); ?>

                                </h4>
                                <p class="fs-sm fw-medium mb-2">
                                    <span class="text-primary"></span>
                                    <?php echo e($blog->created_at->format('F j, Y, g:i a')); ?> <span
                                        class="text-muted"></span>
                                </p>
                                <p class="fs-sm text-muted">
                                    <?php echo e(substr(strip_tags(html_entity_decode($blog->text)), 0, 70) . ' ....'); ?>

                                </p>
                            </div>
                        </a>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <!-- Pagination -->
                <?php echo e($blogs->links()); ?>

                <!-- END Pagination -->
            </div>
        </div>
        <!-- END Story -->




        


        <div class="col-lg-2">
            <div class="row ">

                <?php $__currentLoopData = $rightBars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ind => $rightBar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="col-lg-12">
                        <a class="block block-rounded block-link-pop overflow-hidden" href="<?php echo e($rightBar->link); ?>">
                            <img class="img-fluid" src="<?php echo e(asset('storage/right-bars/' . $rightBar->image)); ?>"
                                alt="">
                            <div class="block-content">

                                <p class="fs-sm text-primary">
                                    <?php echo e($rightBar->description); ?>

                                </p>
                            </div>
                        </a>
                    </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>


        


    </div>

</div>
<?php /**PATH G:\laravel\Blog App\resources\views/livewire/blogs.blade.php ENDPATH**/ ?>