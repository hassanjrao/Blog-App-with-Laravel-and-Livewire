<?php $__env->startSection('page_title', 'Blog - ' . $blog->name); ?>

<?php $__env->startSection('content'); ?>





    <div class="content content-boxed">
        <div class="text-center fs-sm push">
            <span class="d-inline-block py-2 px-4 bg-body fw-medium rounded">
                <a class="link-effect" href="be_pages_generic_profile.html"></a> on
                <?php echo e($blog->created_at->format('F j, Y, g:i a')); ?><span></span>
            </span>
        </div>
        <div class="row justify-content-center">
            <div class="col-sm-8">
                <!-- Story -->
                <h1 class="mb-5 text-center">
                    <?php echo e($blog->name); ?>

                </h1>
                <article class="story">
                    <?php echo $blog->text; ?>

                </article>
                <!-- END Story -->


               <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('comment-on-blog', ['blog' => $blog])->html();
} elseif ($_instance->childHasBeenRendered('vgnbraN')) {
    $componentId = $_instance->getRenderedChildComponentId('vgnbraN');
    $componentTag = $_instance->getRenderedChildComponentTagName('vgnbraN');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('vgnbraN');
} else {
    $response = \Livewire\Livewire::mount('comment-on-blog', ['blog' => $blog]);
    $html = $response->html();
    $_instance->logRenderedChild('vgnbraN', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            </div>
        </div>





    </div>






<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user-backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravel\Blog App\resources\views/blogs/show.blade.php ENDPATH**/ ?>