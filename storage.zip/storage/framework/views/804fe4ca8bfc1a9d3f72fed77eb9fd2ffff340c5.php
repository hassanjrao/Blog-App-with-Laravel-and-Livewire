<?php $__env->startSection('css_before'); ?>
    <!-- Page JS Plugins CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('js/plugins/datatables-bs5/dataTables.bootstrap5.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('js/plugins/datatables-buttons-bs5/buttons.bootstrap5.min.css')); ?>">
<?php $__env->stopSection(); ?>



<?php $__env->startSection('content'); ?>


    <!-- Page Content -->
    <div class="content">

        <a href="<?php echo e(route('admin.blogs.create')); ?>" class="btn btn-primary push">Add Blog</a>


        <div class="block block-rounded">
            <div class="block-header block-header-default">
                <h3 class="block-title">
                    Blogs
                </h3>
            </div>
            <div class="block-content block-content-full">
                <!-- DataTables init on table by adding .js-dataTable-buttons class, functionality is initialized in js/pages/tables_datatables.js -->
                <table class="table table-bordered table-striped table-vcenter js-dataTable-buttons fs-sm">
                    <thead>
                        <tr>
                            <th >#</th>
                            <th>Name</th>
                            <th>Category</th>
                            <th>Text</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ind => $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(++$ind); ?></td>
                                <td><?php echo e($blog->name); ?></td>
                                <td><?php echo e($blog->category->name); ?></td>
                                <td><?php echo e(substr(strip_tags( html_entity_decode($blog->text)), 0, 100) . " ...."); ?></td>

                                <td>
                                    <div class="btn-group" role="group" aria-label="Horizontal Primary">

                                        <a href="<?php echo e(route('admin.blog.comments', $blog->id)); ?>"
                                            class="btn btn-sm btn-alt-info">Comments</a>

                                        <a href="<?php echo e(route('admin.blogs.edit', $blog->id)); ?>"
                                            class="btn btn-sm btn-alt-primary">Edit</a>
                                        <form id="form-<?php echo e($blog->id); ?>"
                                            action="<?php echo e(route('admin.blogs.destroy', $blog->id)); ?>" method="POST">
                                            <?php echo method_field("DELETE"); ?>
                                            <?php echo csrf_field(); ?>
                                            <input type="button" onclick="confirmDelete(<?php echo e($blog->id); ?>)"
                                                class="btn btn-sm btn-alt-danger" value="Delete">

                                        </form>
                                    </div>
                                </td>
                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
    <!-- END Page Content -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_after'); ?>

    <script src="<?php echo e(asset('js/lib/jquery.min.js')); ?>"></script>

    <!-- Page JS Plugins -->
    <script src="<?php echo e(asset('js/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/plugins/datatables-bs5/dataTables.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/plugins/datatables-buttons/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/plugins/datatables-buttons/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/plugins/datatables-buttons/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/plugins/datatables-buttons/buttons.flash.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/plugins/datatables-buttons/buttons.colVis.min.js')); ?>"></script>

    <!-- Page JS Code -->
    <script src="<?php echo e(asset('js/pages/tables_datatables.js')); ?>"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

    <script>
        function confirmDelete(id) {
            swal({
                    title: "Are you sure?",
                    // text: "There may be orders associated with this label, and the orders will get delete to!!",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })
                .then((willDelete) => {
                    if (willDelete) {
                        $("#form-" + id).submit();
                    }
                });

        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.admin-backend", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravel\Blog App\resources\views/admin/blogs/index.blade.php ENDPATH**/ ?>