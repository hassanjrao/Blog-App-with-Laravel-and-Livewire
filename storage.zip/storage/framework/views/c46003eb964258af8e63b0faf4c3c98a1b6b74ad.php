<?php $__env->startSection('css_before'); ?>
<?php $__env->stopSection(); ?>

<?php
    $imagePath="storage/left-bars"
?>

<?php $__env->startSection('content'); ?>


    <!-- Page Content -->
    <div class="content">

        <a href="<?php echo e(route('admin.left-bars.index')); ?>" class="btn btn-primary push">Back to all</a>





        <div class="block block-rounded">
            <div class="block-header block-header-default">
                <h3 class="block-title">Edit Left Bar # <?php echo e($leftBar->id); ?></h3>
                <div class="block-options">
                    <button type="button" class="btn-block-option">
                        <i class="si si-settings"></i>
                    </button>
                </div>
            </div>
            <div class="block-content">
                <form action="<?php echo e(route('admin.left-bars.update',$leftBar->id)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo method_field("PUT"); ?>
                    <?php echo csrf_field(); ?>

                    <div class="row mb-4">

                        <div class="col-lg-12">
                            <label class="form-label" for="link">Link</label>
                            <input type="text" required class="form-control" id="link" name="link" value="<?php echo e($leftBar->link); ?>">
                        </div>

                    </div>

                    <div class="row mb-4">

                        <div class="col-lg-6">
                            <label class="form-label" for="link">Image</label>
                            <input type="file" class="form-control" id="link" name="image">
                            <img class="mt-3" height="200px" width="200px" src="<?php echo e(asset($imagePath."/".$leftBar->image)); ?>" alt="">

                        </div>

                    </div>

                    <div class="mb-4">
                        <!-- CKEditor Container -->
                        <label class="form-label" for="js-ckeditor">Description</label>

                        <textarea class="form-control" name="description" required><?php echo e($leftBar->description); ?></textarea>
                    </div>

                    <div class="mb-4 ">

                        <div class="col-lg-12 text-right">

                            <button class="btn btn-primary">Update</button>
                        </div>
                    </div>

                </form>
            </div>
        </div>


    </div>
    <!-- END Page Content -->


<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_after'); ?>


    
    <!-- Page JS Plugins -->
    <script src="<?php echo e(asset('js/plugins/ckeditor/ckeditor.js')); ?>"></script>
    <script src="<?php echo e(asset('js/plugins/simplemde/simplemde.min.js')); ?>"></script>

    <!-- Page JS Helpers (CKEditor + SimpleMDE plugins) -->
    <script>
        One.helpersOnLoad(['js-ckeditor', 'js-simplemde']);
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.admin-backend", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravel\Blog App\resources\views/admin/left-bars/edit.blade.php ENDPATH**/ ?>