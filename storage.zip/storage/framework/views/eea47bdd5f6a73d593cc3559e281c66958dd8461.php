<?php $__env->startSection('css_before'); ?>
    <!-- Page JS Plugins CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('js/plugins/datatables-bs5/dataTables.bootstrap5.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('js/plugins/datatables-buttons-bs5/buttons.bootstrap5.min.css')); ?>">
<?php $__env->stopSection(); ?>

<?php
    $imagePath="storage/left-bars"
?>


<?php $__env->startSection('content'); ?>


    <!-- Page Content -->
    <div class="content">

        <a href="<?php echo e(route('admin.left-bars.create')); ?>" class="btn btn-primary push">Add</a>


        <div class="block block-rounded">
            <div class="block-header block-header-default">
                <h3 class="block-title">
                    Left bar card
                </h3>
            </div>
            <div class="block-content block-content-full">
                <!-- DataTables init on table by adding .js-dataTable-buttons class, functionality is initialized in js/pages/tables_datatables.js -->
                <table class="table table-bordered table-striped table-vcenter js-dataTable-buttons fs-sm">
                    <thead>
                        <tr>
                            <th >#</th>
                            <th>Link</th>
                            <th>Image</th>
                            <th>Description</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $leftBars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ind => $leftBar): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e(++$ind); ?></td>
                                <td>
                                <a href="<?php echo e($leftBar->link); ?>" href="__blank"><?php echo e($leftBar->link); ?></a>
                                </td>
                                <td>
                                    <img class="img-fluid" src="<?php echo e(asset($imagePath."/".$leftBar->image)); ?>" alt="">
                                </td>
                                <td><?php echo e(substr(strip_tags( html_entity_decode($leftBar->description)), 0, 100) . " ...."); ?></td>

                                <td>
                                    <div class="btn-group" role="group" aria-label="Horizontal Primary">
                                        <a href="<?php echo e(route('admin.left-bars.edit', $leftBar->id)); ?>"
                                            class="btn btn-sm btn-alt-primary">Edit</a>
                                        <form id="form-<?php echo e($leftBar->id); ?>"
                                            action="<?php echo e(route('admin.left-bars.destroy', $leftBar->id)); ?>" method="POST">
                                            <?php echo method_field("DELETE"); ?>
                                            <?php echo csrf_field(); ?>
                                            <input type="button" onclick="confirmDelete(<?php echo e($leftBar->id); ?>)"
                                                class="btn btn-sm btn-alt-danger" value="Delete">

                                        </form>
                                    </div>
                                </td>
                            </tr>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
    <!-- END Page Content -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js_after'); ?>

    <script src="<?php echo e(asset('js/lib/jquery.min.js')); ?>"></script>

    <!-- Page JS Plugins -->
    <script src="<?php echo e(asset('js/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/plugins/datatables-bs5/dataTables.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/plugins/datatables-buttons/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/plugins/datatables-buttons/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/plugins/datatables-buttons/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/plugins/datatables-buttons/buttons.flash.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/plugins/datatables-buttons/buttons.colVis.min.js')); ?>"></script>

    <!-- Page JS Code -->
    <script src="<?php echo e(asset('js/pages/tables_datatables.js')); ?>"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

    <script>
        function confirmDelete(id) {
            swal({
                    title: "Are you sure?",
                    // text: "There may be orders associated with this label, and the orders will get delete to!!",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })
                .then((willDelete) => {
                    if (willDelete) {
                        $("#form-" + id).submit();
                    }
                });

        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layouts.admin-backend", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravel\Blog App\resources\views/admin/left-bars/index.blade.php ENDPATH**/ ?>