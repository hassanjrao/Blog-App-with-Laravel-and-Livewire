<?php $__env->startSection("page_title","Home"); ?>

<?php $__env->startSection('content'); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('blogs', [])->html();
} elseif ($_instance->childHasBeenRendered('CMcoGlB')) {
    $componentId = $_instance->getRenderedChildComponentId('CMcoGlB');
    $componentTag = $_instance->getRenderedChildComponentTagName('CMcoGlB');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('CMcoGlB');
} else {
    $response = \Livewire\Livewire::mount('blogs', []);
    $html = $response->html();
    $_instance->logRenderedChild('CMcoGlB', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user-backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravel\Blog App\resources\views/home.blade.php ENDPATH**/ ?>