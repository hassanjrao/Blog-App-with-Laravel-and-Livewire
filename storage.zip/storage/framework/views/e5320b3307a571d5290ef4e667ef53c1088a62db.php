<?php $__env->startSection("page_title","Category - ".$category->name); ?>

<?php $__env->startSection('content'); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('show-blogs-in-categories', ['categoryId' => $category->id,'category_id' => $category->id])->html();
} elseif ($_instance->childHasBeenRendered('LFzncN3')) {
    $componentId = $_instance->getRenderedChildComponentId('LFzncN3');
    $componentTag = $_instance->getRenderedChildComponentTagName('LFzncN3');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('LFzncN3');
} else {
    $response = \Livewire\Livewire::mount('show-blogs-in-categories', ['categoryId' => $category->id,'category_id' => $category->id]);
    $html = $response->html();
    $_instance->logRenderedChild('LFzncN3', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user-backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\laravel\Blog App\resources\views/categories/show.blade.php ENDPATH**/ ?>